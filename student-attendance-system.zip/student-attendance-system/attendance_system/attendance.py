from datetime import date as _date


def _validate_date(value):
    try:
        return _date.fromisoformat(value).isoformat()
    except ValueError:
        raise ValueError("Date must be in YYYY-MM-DD format.")


def mark_attendance(conn, student_id, date, status):
    """Mark P (present) or A (absent). Re-marking the same day updates it."""
    status = status.strip().upper()
    if status not in ("P", "A"):
        raise ValueError("Status must be 'P' or 'A'.")
    date = _validate_date(date)
    conn.execute(
        """INSERT INTO attendance (student_id, date, status) VALUES (?, ?, ?)
           ON CONFLICT(student_id, date) DO UPDATE SET status = excluded.status""",
        (student_id, date, status),
    )
    conn.commit()


def get_attendance_by_date(conn, date):
    date = _validate_date(date)
    return conn.execute(
        """SELECT s.roll_no, s.name, s.class_name, a.status
           FROM attendance a JOIN students s ON s.id = a.student_id
           WHERE a.date = ? ORDER BY s.roll_no""",
        (date,),
    ).fetchall()
