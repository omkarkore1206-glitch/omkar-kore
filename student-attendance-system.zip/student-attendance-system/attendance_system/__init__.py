"""Student Attendance System - a small CLI project using Python and SQLite."""
