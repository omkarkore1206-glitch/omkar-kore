import sqlite3


def add_student(conn, roll_no, name, class_name):
    roll_no, name, class_name = roll_no.strip(), name.strip(), class_name.strip()
    if not (roll_no and name and class_name):
        raise ValueError("Roll number, name and class are all required.")
    try:
        conn.execute(
            "INSERT INTO students (roll_no, name, class_name) VALUES (?, ?, ?)",
            (roll_no, name, class_name),
        )
        conn.commit()
    except sqlite3.IntegrityError:
        raise ValueError(f"Roll number '{roll_no}' already exists.")


def get_student(conn, roll_no):
    return conn.execute(
        "SELECT * FROM students WHERE roll_no = ?", (roll_no.strip(),)
    ).fetchone()


def list_students(conn):
    return conn.execute("SELECT * FROM students ORDER BY class_name, roll_no").fetchall()


def delete_student(conn, roll_no):
    cur = conn.execute("DELETE FROM students WHERE roll_no = ?", (roll_no.strip(),))
    conn.commit()
    return cur.rowcount > 0
