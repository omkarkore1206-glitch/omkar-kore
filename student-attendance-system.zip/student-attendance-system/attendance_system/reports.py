import csv


def student_summary(conn, roll_no):
    """Return (name, total_days, present_days, percentage) or None if not found."""
    row = conn.execute(
        """SELECT s.name,
                  COUNT(a.id) AS total,
                  COALESCE(SUM(a.status = 'P'), 0) AS present
           FROM students s LEFT JOIN attendance a ON a.student_id = s.id
           WHERE s.roll_no = ? GROUP BY s.id""",
        (roll_no.strip(),),
    ).fetchone()
    if row is None:
        return None
    pct = round(row["present"] * 100 / row["total"], 2) if row["total"] else 0.0
    return row["name"], row["total"], row["present"], pct


def low_attendance(conn, threshold=75.0):
    """Students whose attendance percentage is below the threshold."""
    rows = conn.execute(
        """SELECT s.roll_no, s.name,
                  COUNT(a.id) AS total,
                  SUM(a.status = 'P') AS present
           FROM students s JOIN attendance a ON a.student_id = s.id
           GROUP BY s.id"""
    ).fetchall()
    result = []
    for r in rows:
        pct = round(r["present"] * 100 / r["total"], 2)
        if pct < threshold:
            result.append((r["roll_no"], r["name"], pct))
    return result


def export_csv(conn, path):
    rows = conn.execute(
        """SELECT s.roll_no, s.name, s.class_name, a.date, a.status
           FROM attendance a JOIN students s ON s.id = a.student_id
           ORDER BY a.date, s.roll_no"""
    ).fetchall()
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["roll_no", "name", "class", "date", "status"])
        writer.writerows([tuple(r) for r in rows])
    return len(rows)
