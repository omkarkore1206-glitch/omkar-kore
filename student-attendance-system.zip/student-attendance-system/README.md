# Student Attendance System

A beginner-friendly command-line project to manage students and track daily attendance. Built with **Python** and **SQLite** (no external dependencies).

## Features
- Add, list and delete students
- Mark daily attendance (Present / Absent) and update it later
- View attendance for any date
- Per-student attendance percentage report
- List students below a minimum attendance (default 75%)
- Export all records to CSV

## Project structure
```
student-attendance-system/
├── main.py                     # CLI menu (entry point)
├── attendance_system/
│   ├── __init__.py
│   ├── database.py             # SQLite connection and schema
│   ├── students.py             # student CRUD
│   ├── attendance.py           # marking / viewing attendance
│   └── reports.py              # summaries, low-attendance list, CSV export
├── tests/
│   └── test_attendance.py      # unit tests
├── requirements.txt
├── .gitignore
└── README.md
```

## Getting started
```bash
git clone https://github.com/<your-username>/student-attendance-system.git
cd student-attendance-system
python main.py
```

## Run tests
```bash
python -m unittest discover tests
```

## Database schema
| Table | Columns |
|---|---|
| `students` | id, roll_no (unique), name, class_name |
| `attendance` | id, student_id (FK), date (YYYY-MM-DD), status (`P`/`A`), unique per student per date |

## Future ideas
- Web interface with Flask
- Login for teachers
- Monthly reports and charts

## License
MIT
