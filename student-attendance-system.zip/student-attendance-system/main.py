from datetime import date

from attendance_system import attendance, reports, students
from attendance_system.database import get_connection

MENU = """
===== Student Attendance System =====
1. Add student
2. List students
3. Delete student
4. Mark attendance for a day
5. View attendance by date
6. Student attendance report
7. Low attendance list
8. Export attendance to CSV
0. Exit
"""


def ask_date():
    value = input(f"Date (YYYY-MM-DD, Enter for today): ").strip()
    return value or date.today().isoformat()


def mark_day(conn):
    day = ask_date()
    for s in students.list_students(conn):
        status = input(f"{s['roll_no']} {s['name']} (P/A, Enter to skip): ").strip()
        if status:
            try:
                attendance.mark_attendance(conn, s["id"], day, status)
            except ValueError as e:
                print("  ->", e)


def main():
    conn = get_connection()
    while True:
        print(MENU)
        choice = input("Choose an option: ").strip()
        try:
            if choice == "1":
                students.add_student(
                    conn, input("Roll no: "), input("Name: "), input("Class: ")
                )
                print("Student added.")
            elif choice == "2":
                for s in students.list_students(conn):
                    print(f"{s['roll_no']:<8}{s['name']:<20}{s['class_name']}")
            elif choice == "3":
                ok = students.delete_student(conn, input("Roll no: "))
                print("Deleted." if ok else "Student not found.")
            elif choice == "4":
                mark_day(conn)
            elif choice == "5":
                rows = attendance.get_attendance_by_date(conn, ask_date())
                for r in rows:
                    print(f"{r['roll_no']:<8}{r['name']:<20}{r['status']}")
                if not rows:
                    print("No records for that date.")
            elif choice == "6":
                res = reports.student_summary(conn, input("Roll no: "))
                if res is None:
                    print("Student not found.")
                else:
                    name, total, present, pct = res
                    print(f"{name}: {present}/{total} days present ({pct}%)")
            elif choice == "7":
                for roll, name, pct in reports.low_attendance(conn):
                    print(f"{roll:<8}{name:<20}{pct}%")
            elif choice == "8":
                n = reports.export_csv(conn, "attendance_export.csv")
                print(f"Exported {n} records to attendance_export.csv")
            elif choice == "0":
                print("Goodbye!")
                break
            else:
                print("Invalid option.")
        except ValueError as e:
            print("Error:", e)
    conn.close()


if __name__ == "__main__":
    main()
