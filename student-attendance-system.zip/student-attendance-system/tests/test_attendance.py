import unittest

from attendance_system import attendance, reports, students
from attendance_system.database import get_connection


class AttendanceTests(unittest.TestCase):
    def setUp(self):
        self.conn = get_connection(":memory:")
        students.add_student(self.conn, "101", "Asha", "10A")
        students.add_student(self.conn, "102", "Ravi", "10A")
        self.asha = students.get_student(self.conn, "101")
        self.ravi = students.get_student(self.conn, "102")

    def test_duplicate_roll_rejected(self):
        with self.assertRaises(ValueError):
            students.add_student(self.conn, "101", "Other", "10B")

    def test_mark_and_update(self):
        attendance.mark_attendance(self.conn, self.asha["id"], "2026-01-05", "A")
        attendance.mark_attendance(self.conn, self.asha["id"], "2026-01-05", "P")
        rows = attendance.get_attendance_by_date(self.conn, "2026-01-05")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["status"], "P")

    def test_invalid_inputs(self):
        with self.assertRaises(ValueError):
            attendance.mark_attendance(self.conn, self.asha["id"], "05-01-2026", "P")
        with self.assertRaises(ValueError):
            attendance.mark_attendance(self.conn, self.asha["id"], "2026-01-05", "X")

    def test_summary_and_low_attendance(self):
        for d, s in [("2026-01-05", "P"), ("2026-01-06", "P"), ("2026-01-07", "A"), ("2026-01-08", "P")]:
            attendance.mark_attendance(self.conn, self.asha["id"], d, s)
        for d in ("2026-01-05", "2026-01-06"):
            attendance.mark_attendance(self.conn, self.ravi["id"], d, "A")
        self.assertEqual(reports.student_summary(self.conn, "101"), ("Asha", 4, 3, 75.0))
        self.assertEqual([r[0] for r in reports.low_attendance(self.conn)], ["102"])

    def test_delete_cascades(self):
        attendance.mark_attendance(self.conn, self.asha["id"], "2026-01-05", "P")
        students.delete_student(self.conn, "101")
        self.assertEqual(attendance.get_attendance_by_date(self.conn, "2026-01-05"), [])


if __name__ == "__main__":
    unittest.main()
